<?php
include_once 'connection/connection.inc.php';

if(isset($_POST['searched_name'])){
	if(!empty($_POST['searched_name'])){
        
       if(strpos(trim($_POST['searched_name']), ' ')){
       	 $name = explode(' ', trim($_POST['searched_name']));
       	 $sql = "SELECT * FROM users WHERE first_name LIKE '{$name[0]}%' OR last_name LIKE '%{$name[1]}' ";
       	
      
       }
       else{
          $name = trim($_POST['searched_name']);
          	$sql = "SELECT * FROM users WHERE first_name LIKE '%{$name}%' OR last_name LIKE '%{$name}%' ";
       }
        	$result = mysqli_query($con, $sql);
       	if($result){
           $output = "<table class='table' id='view_table'>
              <tr>
                    <th>Id</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Action</th>
              </tr>";
       		if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_assoc($result)){
              $output = $output . "<tr>
                <td>{$row['id']}</td>
                <td>{$row['first_name']}</td>
                <td>{$row['last_name']}</td>
                <td>{$row['email']}</td>
                <td>{$row['phone']}</td>
                <td>
                <button id='delete-{$row['id']}' class='btn btn-danger del-btn'><img src='assets/images/icon-delete.png' alt=''></button>
                <button id='update-{$row['id']}' class='btn btn-success edit-btn'><img src='assets/images/icon-edit.png' alt=''></button>
                </td>
              </tr>";
            }
              
        
        
                          echo $output;
       		}
       		else{
       			echo 0;
       		}

       	 }
	}
}


?>