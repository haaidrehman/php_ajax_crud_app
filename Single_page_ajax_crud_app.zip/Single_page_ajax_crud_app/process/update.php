<?php
require_once 'connection/connection.inc.php';

if(isset($_POST['id']) && isset($_POST['first_name']) && isset($_POST['last_name']) && isset($_POST['email']) && isset($_POST['phone'])){
	if(!empty($_POST['id']) && !empty($_POST['first_name']) && !empty($_POST['last_name']) && !empty($_POST['email']) && !empty($_POST['phone'])){
        
        $id = mysqli_real_escape_string($con, $_POST['id']);
        $first_name = mysqli_real_escape_string($con, $_POST['first_name']);
        $last_name = mysqli_real_escape_string($con, $_POST['last_name']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $phone = mysqli_real_escape_string($con, $_POST['phone']);

		$sql = "UPDATE users SET first_name = '{$first_name}', last_name = '{$last_name}', email = '{$email}', phone = '{$phone}' WHERE id = '{$id}' ";

		$status = mysqli_query($con, $sql);
		if($status){
			$record['status'] = 1;
		}
		else{
			$record['status'] = 0;
		}
		echo json_encode($record);

	}
}

?>