<?php
include_once 'connection/connection.inc.php';

$sql = "SELECT * FROM users";

$result = mysqli_query($con, $sql);
if($result){
	$output = '';
	if(mysqli_num_rows($result) > 0){

        $output = "<table class='table' id='view_table'>
				      <tr>
				            <th>Id</th>
				            <th>First Name</th>
				            <th>Last Name</th>
				            <th>Email</th>
				            <th>Phone</th>
				            <th>Action</th>
				      </tr>";
		while($record = mysqli_fetch_assoc($result)){
		  	
				
		$output = $output . "<tr>
								<td>{$record['id']}</td>
								<td>{$record['first_name']}</td>
								<td>{$record['last_name']}</td>
								<td>{$record['email']}</td>
								<td>{$record['phone']}</td>
								<td>
								<button id='delete-{$record['id']}' class='btn btn-danger del-btn'><img src='assets/images/icon-delete.png' alt=''></button>
								<button id='update-{$record['id']}' class='btn btn-success edit-btn'><img src='assets/images/icon-edit.png' alt=''></button>
								</td>
							</tr>";
				
		  	
             
		  }
  
  $output = $output . "</table>";
mysqli_close($con);
echo $output;
		  
	}
  
}
else{
	echo "Something went wrong".mysqli_error($con);
}


?>