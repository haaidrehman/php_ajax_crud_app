<?php
require_once 'connection/connection.inc.php';

$record['record'] = 0;
if(isset($_POST['edit_id'])){
	if(!empty($_POST['edit_id'])){
		$id = $_POST['edit_id'];
        $id = substr($id, 7);
        // echo $id;
		$sql = "SELECT * FROM users WHERE id = '$id' ";

		$status = mysqli_query($con, $sql);
		if($status){
			if(mysqli_num_rows($status) > 0){
				$record = mysqli_fetch_assoc($status);
				$record['record'] = 1;
			}
		}
	}
}

  echo json_encode($record);

?>