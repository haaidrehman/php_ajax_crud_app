<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'users_database';

$con = mysqli_connect($servername, $username, $password, $dbname);

if(!$con){
	echo 'Connection error'.mysqli_connect_error();
}

?>