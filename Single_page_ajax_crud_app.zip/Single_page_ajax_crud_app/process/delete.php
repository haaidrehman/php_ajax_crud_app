<?php
require_once 'connection/connection.inc.php';

if(isset($_POST['delete_id'])){
	if(!empty($_POST['delete_id'])){
		$getId = mysqli_real_escape_string($con, $_POST['delete_id']);
		$getId = substr($getId, 7);
         
		$sql = "DELETE FROM users WHERE id = '$getId' ";
		$delSuccess = mysqli_query($con, $sql);
		if($delSuccess){
           echo json_encode(['del_status' => 1]);
		}
		else{
           echo json_encode(['del_status' => 0]);
		}
	}
}

?>