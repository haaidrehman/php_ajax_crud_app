<?php
require_once 'connection/connection.inc.php';

if(isset($_POST['fname']) && isset($_POST['lname']) && isset($_POST['email']) && isset($_POST['phone'])){

$fname = mysqli_real_escape_string($con, $_POST['fname']);
$lname = mysqli_real_escape_string($con, $_POST['lname']);
$email = mysqli_real_escape_string($con, $_POST['email']);
$phone = mysqli_real_escape_string($con, $_POST['phone']);


$sql = "INSERT INTO users (first_name, last_name, email, phone) VALUES('$fname', '$lname', '$email', '$phone') ";
        
        $status = mysqli_query($con, $sql);
        
        if($status){
        	echo json_encode(['insert_status' => 1]);
        }
        else{
        	echo json_encode(['insert_status' => 0]);
        }
}


?>