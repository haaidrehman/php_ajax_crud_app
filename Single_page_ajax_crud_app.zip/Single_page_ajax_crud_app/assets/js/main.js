$(document).ready(function(){

// new
function load_table_records(){
  $.ajax({
    url : 'process/load.php',
    method : 'post',
    success : function(response){
        $('#view_table').html(response);
    }
  });
} 

load_table_records();



//new
  $('.close-btn').on('click', function(){
       $('#edit_modal').css('display', 'none');
  });

  $('#add_user_btn').on('click', function(){

    var html =  `<div class="form-group">
                          <label for="">First Name</label>
                           <input type="text" name="first_name" id="first_name" class="form-control">
                           <span id='fname_err' class='err-msg'></span>
                         </div>
                         <div class="form-group">
                           <label for="">Last Name</label>
                           <input type="text" name="last_name" id="last_name" class="form-control">
                            <span id='lname_err' class='err-msg'></span>
                         </div>
                         
                          <div class="form-group">
                             <label for="">Email</label>
                            <input type="text" name="email" id="email" class="form-control">
                             <span id='email_err' class='err-msg'></span>
                         </div>
                           
                           <div class="form-group">
                             <label for="">Phone</label>
                             <input type="text" name="phone" id="phone" class="form-control">
                              <span id='phone_err' class='err-msg'></span>
                         </div>
                           
                            <div class="form-group">
                               <input type="hidden" id="student_id">
                               <input type="submit" name="submit" id="insert_user" value="Save" class="btn btn-success">
                         </div>`;

        $('#updation_form').html(html);                     

        $('#edit_modal').css('display', 'block');

  });
  
	// Send the input filed data to insert.php file
	$(document).on('click', '#insert_user', function(e){
        e.preventDefault();

        $('.err-msg').text('');
        var fname = $('#first_name').val();
        var lname = $('#last_name').val();
        var email = $('#email').val();
        var phone = $('#phone').val();
         
        var err_status = 0; 
        if(fname == ''){

        	// $('#err-msg').text("All fields are required");
        	// $('#err-msg').slideDown();
         //    $('#success-msg').slideUp();
         //    $('#success-msg').hide();

          $('#fname_err').text('First name is required');
          $('#fname_err').slideDown();
          err_status = 1; 
        }
        if(lname == ''){
            $('#lname_err').text('Last name is required');
             $('#lname_err').slideDown();
            err_status = 1; 
        }
        if(email == ''){
           $('#email_err').text('Email is required');
            $('#email_err').slideDown();
          err_status = 1; 

        }
        if(phone == ''){
            $('#phone_err').text('Phone is required');
             $('#phone_err').slideDown();
          err_status = 1; 
        }

        if(err_status == 0){
           $.ajax({
              url : 'process/insert.php',
              method : 'post',
              data : {
                fname : fname,
                lname : lname,
                email : email,
                phone : phone
              },
              dataType: 'json',
              success : function(response){
                 if(response.insert_status == 1){
                     load_table_records();
                 }
              }
           });
        }
	});
  // new end


	// Delete the record using unique id
	$(document).on('click', '.del-btn', function(){
		$('#success-msg').hide();
		if(confirm("Do you really want to delete this record ?")){
            var deleteId = $(this).attr('id');
        var element = $(this);
        $.ajax({
        	url : 'process/delete.php',
        	method : 'post',
        	data : {
        		delete_id : deleteId
        	},
          dataType : 'json',
            success : function(response){
              
              
              if(response.del_status == 1){
                 // load_table_records();
                 var tr = $(element).closest('tr');
                 $(tr).fadeOut();
              }
            }
        });
		}
        
	});
   

   // Open a modal when clicked on edit button
   $(document).on('click', '.edit-btn', function(){

   	  $('#success-msg').hide();
   	  var getEditId = $(this).attr('id');
       //console.log(getEditId);
   	  $.ajax({
   	  	url : 'process/select-record.php',
   	  	method : 'post',
   	  	data : {
   	  		edit_id : getEditId
   	  	},
        dataType : 'json',
   	  	success: function(data){
           console.log(data);
           if(data.record != 0){
                 var html = `<div class="form-group">
                          <label for="">First Name</label>
                           <input type="text" name="first_name" id="first_name" value="${data.first_name}" class="form-control">
                         </div>
                         <div class="form-group">
                           <label for="">Last Name</label>
                           <input type="text" name="last_name" id="last_name" value="${data.last_name}" class="form-control">
                         </div>
                         
                          <div class="form-group">
                             <label for="">Email</label>
                            <input type="text" name="email" id="email" value="${data.email}" class="form-control">
                         </div>
                           
                           <div class="form-group">
                             <label for="">Phone</label>
                             <input type="text" name="phone" id="phone" value="${data.phone}" class="form-control">
                         </div>
                           
                            <div class="form-group">
                               <input type="hidden" id="student_id" value="${data.id}">
                               <input type="submit" name="submit" id="save" value="Save" class="btn btn-success">
                         </div>`;

                         $('#updation_form').html(html);
                         $('#edit_modal').css('display', 'block');


           }
        
   	  	}
   	  }); 

   });
	
	$('#modal-close').click(function(){
		$('#modal').hide();
	});



  // Update the single record when clicked on Save button and also retrieve total total record uisng load_table_records() function
	$(document).on('click', '#save', function(e){
		e.preventDefault();
		var id = $('#student_id').val();
		var first_name = $('#first_name').val();
		var last_name = $('#last_name').val();
    var email = $('#email').val();
    var phone = $('#phone').val();
		
		$.ajax({
			url : 'process/update.php',
			method : 'post',
			data : {
				id : id,
				first_name : first_name,
				last_name : last_name,
        email : email,
        phone : phone
			},
      dataType : 'json',
			success : function(data){
              if(data.status == 1){
                $('#edit_modal').css('display', 'none');
                load_table_records();
              }
			} 
		});
	});


    // Live search
    $('#search').on('keyup', function(){
    	console.log('search bar clicked');
    	var searchText = $(this).val();
      
      $('#live_search_err_msg').css('display', 'none');

    	$('#textDisp').text(searchText);

    	$.ajax({
    		url : 'process/live-search.php',
    		method : 'post',
    		data : {
    			searched_name : searchText
    		},
    		success : function(response){
           
              if(response == 0){
                console.log('YES');
                $('#live_search_err_msg').css('display', 'block');
               	 $('#view_table').hide();
               }
               else{
                 $('#view_table').html(response);
                 $('#view_table').show();
               }
    		}
    	}); 
    });
});





