
<!-- <table id="main" border="0" cellpadding="0" class="table">
  <tr>
  	<td id="header" align="center">
  		<h1>PHP With AJAX</h1>
  		<div id="search-bar">
  			<label>Search:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  			<input type="text" id="search" autocomplete="off">
  			<div id="textDisp" style=""></div>
  		</div>
  	</td>
  </tr>	
  <tr>
  	<td id="table-data">
  		<table border="1" width="100%" cellpadding="0" cellpadding="10px">
     	<tr>
     		<th align="center">Id</th>
     		<th align="center">Name</th>
     		<th>Action</th>
     	</tr>
     </table> 
  	</td>   	
  </tr>
</table>
 -->

<!-- <div id="err-msg"></div>

<div id="modal" style="background: red; width: 100px; height: 100px;">
    hello
</div> -->
<?php 
require_once 'assets/templates/header.inc.php';
?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-3">
      <div class="mt-4 add-btn"><button class="btn btn-primary" id="add_user_btn"><img src="assets/images/icon-add.png" alt=""></button>
      </div>
    </div>
    <div class="col-md-4 col-sm-8 offset-md-3 offset-sm-1">
      <div class="search-bar">
        <table>
          <tr>
            <td><label>Search:&nbsp;&nbsp;&nbsp;</label></td>
            <td><input type="text" name="search" id="search" class="form-control"></td>
          </tr>
        </table>
      </div>
    </div>
    <div class="col-md-12">
      <table class="table" id="view_table">
        <!--  <tr>
          <th align="center">Id</th>
          <th align="center">First Name</th>
          <th align="center">Last Name</th>
          <th align="center">Email</th>
          <th align="center">Phone</th>
          <th width="200px">Action</th>
        </tr> -->
      </table>
    </div>
  </div>
</div>
<div id="edit_modal">
  <div class="modal_bg">
    <div class="modal-header">
      <h3>Edit details here</h3>
      <span class="close-btn">X</span>
    </div>
    <div class="modal-body">
      <form action="" id="updation_form">
        
      </form>
    </div>
  </div>
  
</div>

<div class="text-center">
  <span id="live_search_err_msg">No record found</span>
</div>
<?php require_once 'assets/templates/footer.inc.php'; ?>